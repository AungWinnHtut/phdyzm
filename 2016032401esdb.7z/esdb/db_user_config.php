<?php

/*
 * All database connection variables
 */

define('DB_USER', "admin"); // db user
define('DB_PASSWORD', "admin"); // db password (mention your db password here)
define('DB_DATABASE', "esdb"); // database name
define('DB_SERVER', "localhost"); // db server
?>
<?php
	$conn = mysqli_connect("localhost","admin","admin","esdb") or die(mysqli_error());	
?>
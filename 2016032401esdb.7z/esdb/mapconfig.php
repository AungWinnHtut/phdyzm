<?php
/*define('DB_USER','p0_1244531');
define('DB_PASSWORD','wailii');
define('DB_HOST','sql2.php0h.com');
define('DB_NAME','p0_1244531_googlemap'); */
define('DB_USER','root');
define('DB_PASSWORD','root');
define('DB_HOST','localhost');
define('DB_NAME','map');
$mysqli=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME) or die(mysqli_error());
?>
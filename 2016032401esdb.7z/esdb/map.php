<?php 
//include('config.php');
//$sql="SELECT * FROM gmap";
//$result=mysqli_query($mysqli,$sql) or die(mysqli_error());
//$count=0;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
<head>
<script src="https://maps.googleapis.com/maps/api/js?callback=initMap" type="text/javascript" charset="utf-8"></script><script type="text/javascript" charset="utf-8">
//<![CDATA[

//http://localhost/esdb/map.php?name=Hello&address=pol&lat=22.024104&lng=96.447339
if (isset($_GET['name'])){
    //Read input data according to their name and save in variables
      //$id=$row['id'];
      $name=addslashes($_GET['name']);
      $address=$_GET['address'];
      $lat=$_GET['lat'];
      $lng=$_GET['lng'];
      //$type=$_GET['type'];  

}


var points = [];
var markers = [];
var counter = 0;
var sidebar_html = "";
var marker_html = [];
var to_htmls = [];
var from_htmls = [];
var map = null;

function onLoad() {
if (GBrowserIsCompatible()) {
var mapObj = document.getElementById("map");
if (mapObj != "undefined" && mapObj != null) {
map = new GMap2(document.getElementById("map"));
//// TO DO
map.setCenter(new GLatLng(22.024104,96.447339), 15, G_NORMAL_MAP);
var bds = new GLatLngBounds(new GLatLng(22.024104,96.447339), new GLatLng(22.024104,96.447339));
////
map.setZoom(map.getBoundsZoomLevel(bds));
map.addControl(new GLargeMapControl());
map.addControl(new GMapTypeControl());
map.addControl(new GScaleControl())
<?php
	
	echo "var point = new GLatLng({$lat},{$lng});\n";
	?>
	var marker = createMarker(point,"<?php echo $name; ?>","<div id=\"gmapmarker\"><b><?php echo $name;?><\/b><\/div>",<?php echo $count; ?>,"");

	map.addOverlay(marker);
	

}
} else {
alert("Sorry, the Google Maps API is not compatible with this browser.");
}
}
function createMarker(point, title, html, n, tooltip) {
if(n >= 0) { n = -1; }
var marker = new GMarker(point,{'title': tooltip});
var tabFlag = isArray(html);
if(!tabFlag) { html = [{"contentElem": html}]; }
to_htmls[counter] = html[0].contentElem + '<form class="gmapDir" id="gmapDirTo" style="white-space: nowrap;" action="http://maps.google.com/maps" method="get" target="_blank">' +
                     '<span class="gmapDirHead" id="gmapDirHeadTo">Directions: <strong>To here</strong> - <a href="javascript:fromhere(' + counter + ')">From here</a></span>' +
                     '<p class="gmapDirItem" id="gmapDirItemTo"><label for="gmapDirSaddr" class="gmapDirLabel" id="gmapDirLabelTo">Start address: (include addr, city st/region)<br /></label>' +
                     '<input type="text" size="40" maxlength="40" name="saddr" class="gmapTextBox" id="gmapDirSaddr" value="" onfocus="this.style.backgroundColor = \'#e0e0e0\';" onblur="this.style.backgroundColor = \'#ffffff\';" />' +
                     '<span class="gmapDirBtns" id="gmapDirBtnsTo"><input value="Get Directions" type="submit" class="gmapDirButton" id="gmapDirButtonTo" /></span></p>' +
                     '<input type="hidden" name="daddr" value="' +
                     point.y + ',' + point.x + "(" + title.replace(new RegExp(/"/g),'&quot;') + ")" + '" /></form>';
                      from_htmls[counter] = html[0].contentElem + '<p /><form class="gmapDir" id="gmapDirFrom" style="white-space: nowrap;" action="http://maps.google.com/maps" method="get" target="_blank">' +
                     '<span class="gmapDirHead" id="gmapDirHeadFrom">Directions: <a href="javascript:tohere(' + counter + ')">To here</a> - <strong>From here</strong></span>' +
                     '<p class="gmapDirItem" id="gmapDirItemFrom"><label for="gmapDirSaddr" class="gmapDirLabel" id="gmapDirLabelFrom">End address: (include addr, city st/region)<br /></label>' +
                     '<input type="text" size="40" maxlength="40" name="daddr" class="gmapTextBox" id="gmapDirSaddr" value="" onfocus="this.style.backgroundColor = \'#e0e0e0\';" onblur="this.style.backgroundColor = \'#ffffff\';" />' +
                     '<span class="gmapDirBtns" id="gmapDirBtnsFrom"><input value="Get Directions" type="submit" class="gmapDirButton" id="gmapDirButtonFrom" /></span></p>' +
                     '<input type="hidden" name="saddr" value="' +
                     point.y + ',' + point.x + encodeURIComponent("(" + title.replace(new RegExp(/"/g),'&quot;') + ")") + '" /></form>';
                     html[0].contentElem = html[0].contentElem + '<p /><div id="gmapDirHead" class="gmapDir" style="white-space: nowrap;"></div>';
if(!tabFlag) { html = html[0].contentElem; }if(isArray(html)) { GEvent.addListener(marker, "click", function() { marker.openInfoWindowTabsHtml(html); }); }
else { GEvent.addListener(marker, "click", function() { marker.openInfoWindowHtml(html); }); }
points[counter] = point;
markers[counter] = marker;
marker_html[counter] = html;
sidebar_html += '<li class="gmapSidebarItem" id="gmapSidebarItem_'+ counter +'"><a href="javascript:click_sidebar(' + counter + ')">' + title + '<\/a><\/li>';
counter++;
return marker;
}
function isArray(a) {return isObject(a) && a.constructor == Array;}
function isObject(a) {return (a && typeof a == 'object') || isFunction(a);}
function isFunction(a) {return typeof a == 'function';}
function click_sidebar(idx) {
  if(isArray(marker_html[idx])) { markers[idx].openInfoWindowTabsHtml(marker_html[idx]); }
  else { markers[idx].openInfoWindowHtml(marker_html[idx]); }
}
function showInfoWindow(idx,html) {
map.centerAtLatLng(points[idx]);
markers[idx].openInfoWindowHtml(html);
}
function tohere(idx) {
markers[idx].openInfoWindowHtml(to_htmls[idx]);
}
function fromhere(idx) {
markers[idx].openInfoWindowHtml(from_htmls[idx]);
}
//]]>
</script>
</head>
<body onload="onLoad()">

<table border=0>
<tr><td>
<script type="text/javascript" charset="utf-8">
//<![CDATA[
if (GBrowserIsCompatible()) {
document.write('<div id="map" style="width: 500px; height: 500px"><\/div>');
} else {
document.write('<b>Javascript must be enabled in order to use Google Maps.<\/b>');
}
//]]>
</script>
<noscript><b>Javascript must be enabled in order to use Google Maps.</b></noscript>

</td><td>
<div id="sidebar_map"></div>
</td></tr>
</table>
<p>

<pre id="out"></pre>


<script type="text/javascript">
<!-- begin hiding
function showGMapForm() {
  alert(document.getElementById('gmapDirFrom'));
}

function showForm() {
  var out = document.getElementById('out');
  var s = document.getElementById('gmapDirFrom').innerHTML;
  s = s.replace(/</g, '&lt;');
  s = s.replace(/>/g, '&gt;');
  out.innerHTML = s;
}

function attachOnsubmitEvents() {
  var form = document.getElementById('gmapDirFrom');
  form.onsubmit = function() {
    alert(this.elements['daddr']);
    return false;
  };
}
// end hiding -->
</script>

</body>
</html>

<?php	
	
	// include db connect class
	require_once __DIR__ . '/db_user_connect.php';

	// connecting to db
	$con = new DB_CONNECT();
	$con->connect();
	/////////////////////////////////////
	//	$sql = "SELECT * FROM category";
	//	$res = mysqli_query($con->myconn, $sql );
	//	while ($row = mysqli_fetch_assoc($res)){
	//		$cat_id = $row['catid'];
	//		$name = $row['name'];		
	//}
	///////////////////////////////////
	if (isset($_GET['catalog'])){
		//Read input data according to their name and save in variables
		$catalog = $_GET['catalog'];
		$rating =$_GET['rating'];
		$p1 = $_GET['p1'];
		$p2 = $_GET['p2'];	
		$cui = $_GET['cuisine'];
		
		$x0 = $_GET['x0'];		
		$y0 = $_GET['y0'];	
		$r = $_GET['r'];
		



		//echo $x0.$y0.$r;
		//	TO DO * add range, x0, y0 here *** need to add in android to ask
		//	$range = $_GET['range'];
		//	$cur_lat = $_GET['cur_lat'];
		//	$cur_lng = $_GET['cur_lng'];
		//  if cur_lat and cur_lng = 0 then default value is 22.023966, 96.447359

		//	sample data
		//	$catalog = "hotel";
		//	$rating ="2";
		//	$p1 = "10";
		//	$p2 = "1000";	
		//	$cui = "chinese";	
		//	$x0 =
		//  $y0 =
		//  $r = 
		// https://www.google.com.mm/maps/@22.055673,96.510153,25z?hl=en
		//http://localhost/esdb/search3.php?catalog=hotel&rating=1&p1=10&p2=1000&cuisine=Burmese&x0=22.055673&y0=96.510153&r=1000
	
		function getDistance($lat1, $lng1, $lat2, $lng2)
		{
    	// radius of earth; @note: the earth is not perfectly spherical, but this is considered the 'mean radius'
    	$radius = 6371.009; // in kilometers
    	//elseif ($unit == 'mi') $radius = 3958.761; // in miles

    	// convert degrees to radians
    	$lat1 = deg2rad((float) $lat1);
    	$lng1 = deg2rad((float) $lng1);
    	$lat2 = deg2rad((float) $lat2);
    	$lng2 = deg2rad((float) $lng2);

    	// great circle distance formula
    	return $radius * acos(sin($lat1) * sin($lat2) + cos($lat1) * cos($lat2) * cos($lng1 - $lng2));
		}


		//1-Debug information save in search3.log (input parameters)
		$myfile = fopen("search3.log", "w") or die("Unable to open file!");
    	fwrite($myfile, "\ninputs cat_name=".$catalog." rating=".$rating." p1=".$p1." cursine=".$cui." \n");
    	fwrite($myfile, "\nx0=".$x0." y0=".$y0." r=".$r. " \n");
    	fclose($myfile);

			
		
		//$sql = "SELECT information.name AS info_name, $catalog.*,information.* 
		//FROM information inner join $catalog on information.id= $catalog.info_id 
		//WHERE information.rating like '%$rating%'  OR $catalog.cuisine like '%$cui%' 
		//OR  BETWEEN $catalog.price_high=$p2 AND $catalog.price_low=$p1  
		//GROUP BY information.name "  ;

		
		$sql = "SELECT information.name AS 
					info_name, 
					$catalog.*,
					information.* 


				FROM 
					information 
				inner join 
					$catalog 
				on 
					information.id= $catalog.info_id 
				WHERE 
					information.rating like '%$rating%'  
					OR $catalog.cuisine like '%$cui%'  
					AND  $p1 BETWEEN $catalog.price_high 
					AND $catalog.price_low 
					AND   $p2 BETWEEN $catalog.price_high 
					AND $catalog.price_low   
				GROUP BY 
					information.name "  ;
		
		//2-Debug information save in search3.log (sql string)
		$myfile = fopen("search3.log", "a") or die("Unable to open file!");
    	fwrite($myfile, "\n sql".$sql." \n");
    	fclose($myfile);

		//Starting query
		$res = mysqli_query($con->myconn,$sql) or die(mysqli_error());
		
		//Extracting rows from result
		$row = mysqli_num_rows($res);

		//3-Debug information save in search3.log (rows from result)
		$myfile = fopen("search3.log", "a") or die("Unable to open file!");
    	fwrite($myfile, "\n Roll  ".$row." \n");
    	fclose($myfile);

    	//if there is data?
		if($row> 0){
			
			//if the lat and long are valid???
			//4-Debug information save in search3.log (flag about data exist)
			$myfile = fopen("search3.log", "a") or die("Unable to open file!");
    		fwrite($myfile, "\n data exist \n");    			
    		fclose($myfile);

    		//create two dimensional array for every data resulted
			$response["result"]=array(); 
			while ($row = mysqli_fetch_assoc($res)){
				//create new empty array to store data from one row
				$found = array(); 
				//save every column data from one row in empty array found
				//first finding lat and lng
				//$latitute = $row['lat'];
				//$Longitude = $row['lng'];

				//if(checkRange($latitute,$Longitude,$range,$cur_lat,$cur_lng)){

				// TO DO * lat lng cause problem in android
				//$found['lat'] = $Latitute;
				//$found['lng'] = $Longitude;

				$found['info_name'] = $row['info_name'];	
				$found['address'] = $row['address'];
				$found['phone_no'] = $row['phone_no'];
				$found['lat']	= $row['lat'];
				$found['lng'] = $row['lng'];

				$x1 = $found['lat'];
				$y1 = $found['lng'];
				//echo $x1.$y1;

				if( $r >= getDistance($x0, $y0, $x1, $y1))
				{
					//}else{//Do Nothing} //skip these data


					//save found array into another two dimensional array result
					array_push($response["result"],$found);

					//5-Debug information save in search3.log 
					$myfile = fopen("search3.log", "a") or die("Unable to open file!");
    				fwrite($myfile, "\nInfoname=".$row['info_name']." Address=".
    							$row['address']." Phone no=".$row['phone_no'].
    							"\nLat=".$row['lat']." Lng=".$row['lng']." \n");
    				fclose($myfile);
				}

				

			}

			//Add success flag 1 into two dimentional array response
			$response["success"]=1;

			//Creat Final JSON by encoding two dimentional array response and ECHO it
			echo json_encode($response);
		}
		else{
			//if no rows or data success Flags =0 and add to two dimentional array $response
			$response["success"]=0;
			//add error message in two dimentional array $response
			$response["message"]="Not found";
			//Creat Final JSON by encoding two dimentional array response and ECHO it 
			//(only two error code included)
			echo json_encode($response);
		}
		
	}
	

	// check for empty result from query
		if ($res){
    		// success
    		$response["success"] = 1;
    		// echoing JSON response
    		echo json_encode($response);
		} else {
			$myfile = fopen("search3.log", "a") or die("Unable to open file!");
    		fwrite($myfile, "\nno inputs \n");    		
    		fclose($myfile);

    		// no logins found
    		$response["success"] = 0;
    		$response["message"] = "No detail found";
    		// echo no users JSON
    		echo json_encode($response);
		}
?>
